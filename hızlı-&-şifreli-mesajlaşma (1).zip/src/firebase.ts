import { initializeApp } from "firebase/app";
import { getAuth, signInAnonymously } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCP0Rd8CAfzYRPtakfdQWBqS5uBn045XpE",
  authDomain: "hizliyimforum.firebaseapp.com",
  databaseURL: "https://hizliyimforum-default-rtdb.firebaseio.com",
  projectId: "hizliyimforum",
  storageBucket: "hizliyimforum.firebasestorage.app",
  messagingSenderId: "903963422468",
  appId: "1:903963422468:web:936c368393585efd0cea51"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export const loginAnonymously = () => signInAnonymously(auth);
