// src/utils/crypto.ts

// Yardımcı Fonksiyonlar: Base64 Çeviriciler
export function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function base64ToBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

// 1. Anonim Odalar İçin Rastgele AES-GCM Anahtarı Üretme
export async function generateRoomKey(): Promise<CryptoKey> {
  return await window.crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
}

// Anahtarı Base64 String'e Çevirme (URL veya Input için)
export async function exportKeyToBase64(key: CryptoKey): Promise<string> {
  const exported = await window.crypto.subtle.exportKey('raw', key);
  return bufferToBase64(exported);
}

// Base64 String'i Anahtara Çevirme
export async function importKeyFromBase64(base64: string): Promise<CryptoKey> {
  const buffer = base64ToBuffer(base64);
  return await window.crypto.subtle.importKey(
    'raw',
    buffer,
    { name: 'AES-GCM' },
    true,
    ['encrypt', 'decrypt']
  );
}

// Özel Odalar İçin Paroladan (Room ID) Anahtar Türetme (PBKDF2)
export async function deriveKeyFromPassword(password: string, saltString: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveBits", "deriveKey"]
  );

  return await window.crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: enc.encode(saltString),
      iterations: 100000,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    true,
    ["encrypt", "decrypt"]
  );
}

// 2. Mesaj Şifreleme (AES-GCM + Rastgele IV/Salt)
export async function encryptMessage(text: string, key: CryptoKey): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  
  // Her mesaj için benzersiz bir IV (Initialization Vector) - Bu bir nevi salt görevi görür
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  
  const ciphertext = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv },
    key,
    data
  );
  
  // IV ve Şifreli Metni birleştirip Base64 yapıyoruz
  const ivBase64 = bufferToBase64(iv.buffer);
  const cipherBase64 = bufferToBase64(ciphertext);
  
  return `${ivBase64}:${cipherBase64}`;
}

// 3. Mesaj Şifre Çözme
export async function decryptMessage(encryptedData: string, key: CryptoKey): Promise<string> {
  try {
    const parts = encryptedData.split(':');
    if (parts.length !== 2) throw new Error('Geçersiz şifreli veri formatı');
    
    const iv = base64ToBuffer(parts[0]);
    const ciphertext = base64ToBuffer(parts[1]);
    
    const decryptedBuffer = await window.crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: new Uint8Array(iv) },
      key,
      ciphertext
    );
    
    const decoder = new TextDecoder();
    return decoder.decode(decryptedBuffer);
  } catch (error) {
    console.error('Şifre çözme hatası:', error);
    return '⚠️ Şifre çözülemedi';
  }
}
