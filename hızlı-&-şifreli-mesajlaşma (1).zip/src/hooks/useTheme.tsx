import React, { createContext, useContext, useEffect } from 'react';

interface ThemeContextType {
  isDayTime: boolean;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({ isDayTime: false, toggleTheme: () => {} });

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    document.body.classList.add('night-mode');
    document.body.classList.remove('day-mode');
  }, []);

  return (
    <ThemeContext.Provider value={{ isDayTime: false, toggleTheme: () => {} }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
