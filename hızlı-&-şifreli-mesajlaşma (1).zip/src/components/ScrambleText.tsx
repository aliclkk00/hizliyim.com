import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface ScrambleTextProps {
  text: string;
  className?: string;
  delay?: number;
}

const CHARS = '!<>-_\\/[]{}—=+*^?#________';

export function ScrambleText({ text, className = '', delay = 0 }: ScrambleTextProps) {
  const [displayText, setDisplayText] = useState('');
  const [isRevealed, setIsRevealed] = useState(false);

  useEffect(() => {
    let frame = 0;
    let animationFrameId: number;
    const length = text.length;
    
    // Start with a scrambled string
    const initialScramble = Array.from({ length }).map(() => CHARS[Math.floor(Math.random() * CHARS.length)]).join('');
    setDisplayText(initialScramble);

    const startAnimation = () => {
      const animate = () => {
        frame += 1; // Increase frame speed
        
        // At 15 frames (very fast), it should be fully revealed
        const progress = Math.min(frame / 15, 1);
        
        const currentText = text.split('').map((char, index) => {
          if (char === ' ') return ' ';
          // Reveal characters progressively based on progress
          if (progress >= 1 || Math.random() < progress) {
            return char;
          }
          return CHARS[Math.floor(Math.random() * CHARS.length)];
        }).join('');

        setDisplayText(currentText);

        if (progress < 1) {
          animationFrameId = requestAnimationFrame(animate);
        } else {
          setIsRevealed(true);
        }
      };
      
      animationFrameId = requestAnimationFrame(animate);
    };

    const timer = setTimeout(startAnimation, delay);

    return () => {
      clearTimeout(timer);
      cancelAnimationFrame(animationFrameId);
    };
  }, [text, delay]);

  return (
    <motion.span 
      className={`${className}`}
      initial={{ filter: 'blur(4px)', opacity: 0.8 }}
      animate={isRevealed ? { filter: 'blur(0px)', opacity: 1 } : { filter: 'blur(2px)', opacity: 0.9 }}
      transition={{ duration: 0.2 }}
      style={{ wordBreak: 'break-word', whiteSpace: 'pre-wrap', display: 'inline' }}
    >
      {displayText}
    </motion.span>
  );
}
