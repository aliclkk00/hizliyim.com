import React, { useEffect, useState } from 'react';
import { useTheme } from '../hooks/useTheme';

export function BackgroundEffects() {
  const { isDayTime } = useTheme();
  const [staticStars, setStaticStars] = useState<any[]>([]);
  const [shootingStars, setShootingStars] = useState<any[]>([]);
  const [speedLines, setSpeedLines] = useState<any[]>([]);

  useEffect(() => {
    // Yıldızlar (Hem gece hem gündüz)
    const stars = Array.from({ length: 60 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100 + '%',
      top: Math.random() * 100 + '%',
      size: Math.random() * 2 + 1 + 'px',
      duration: Math.random() * 3 + 2 + 's',
    }));
    setStaticStars(stars);

    // Kayan Yıldızlar
    const shootInterval = setInterval(() => {
      setShootingStars((prev) => {
        if (prev.length > 5) return prev;
        return [
          ...prev,
          {
            id: Date.now(),
            top: Math.random() * 50 + '%',
            left: Math.random() * 100 + '%',
          },
        ];
      });
    }, 2500);

    // Hız Çizgileri
    const speedInterval = setInterval(() => {
      setSpeedLines((prev) => {
        if (prev.length > 5) return prev;
        const isLeft = Math.random() > 0.5;
        return [
          ...prev,
          {
            id: Date.now(),
            top: Math.random() * 100 + 'vh',
            left: isLeft ? '-10%' : 'auto',
            right: isLeft ? 'auto' : '-10%',
          },
        ];
      });
    }, 800);

    return () => {
      clearInterval(shootInterval);
      clearInterval(speedInterval);
    };
  }, []);

  // Temizleme (Kayan yıldızlar ve hız çizgileri için)
  useEffect(() => {
    const cleanup = setInterval(() => {
      setShootingStars((prev) => prev.filter((s) => Date.now() - s.id < 2100));
      setSpeedLines((prev) => prev.filter((s) => Date.now() - s.id < 2100));
    }, 1000);
    return () => clearInterval(cleanup);
  }, []);

  return (
    <>
      <div className="bg-gradient-overlay"></div>
      
      <div id="static-stars-container" style={{ display: 'block' }}>
        {staticStars.map((star) => (
          <div
            key={star.id}
            className="static-star"
            style={{
              left: star.left,
              top: star.top,
              width: star.size,
              height: star.size,
              animationDuration: star.duration,
            }}
          />
        ))}
      </div>
      <div id="night-effects-container" style={{ display: 'block' }}>
        {shootingStars.map((star) => (
          <div
            key={star.id}
            className="shooting-star"
            style={{ top: star.top, left: star.left, animationDuration: '2s' }}
          />
        ))}
        {speedLines.map((line) => (
          <div
            key={line.id}
            className="speed-line"
            style={{
              top: line.top,
              left: line.left,
              right: line.right,
              animationDuration: '0.5s',
            }}
          />
        ))}
      </div>
    </>
  );
}
