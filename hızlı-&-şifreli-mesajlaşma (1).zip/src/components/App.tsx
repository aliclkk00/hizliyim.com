import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthPage } from './pages/AuthPage';
import { Dashboard } from './pages/Dashboard';
import { ChatRoom } from './pages/ChatRoom';
import { SettingsPage } from './pages/SettingsPage';
import { AccountInfoPage } from './pages/AccountInfoPage';
import { BackgroundEffects } from './components/BackgroundEffects';
import { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebase';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return <div className="w-screen h-screen flex items-center justify-center bg-black text-white">Yükleniyor...</div>;
  }

  return (
    <HashRouter>
      <BackgroundEffects />
      
      <Routes>
        <Route path="/" element={(!user || user.isAnonymous) ? <AuthPage /> : <Navigate to="/dashboard" />} />
        <Route path="/dashboard" element={(user && !user.isAnonymous) ? <Dashboard user={user} /> : <Navigate to="/" />} />
        <Route path="/settings" element={(user && !user.isAnonymous) ? <SettingsPage user={user} /> : <Navigate to="/" />} />
        <Route path="/account-info" element={(user && !user.isAnonymous) ? <AccountInfoPage user={user} /> : <Navigate to="/" />} />
        <Route path="/chat/:roomId" element={<ChatRoom user={user} />} />
      </Routes>
    </HashRouter>
  );
}
