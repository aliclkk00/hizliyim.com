import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { signOut, updateEmail, updatePassword } from 'firebase/auth';
import { doc, getDoc, collection, query, where, getDocs, setDoc, onSnapshot, deleteDoc, orderBy, updateDoc } from 'firebase/firestore';
import { GlassPanel } from '../components/GlassPanel';
import { LogOut, UserPlus, MessageSquare, Copy, Check, X, Bell, Clock, Users, User, Mail, Lock, Eye, EyeOff, Shield, Trash2, Ban, ArrowLeft } from 'lucide-react';
import { generateRoomKey, exportKeyToBase64 } from '../utils/crypto';

export function Dashboard({ user }: { user: any }) {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<any>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [showId, setShowId] = useState(false);
  
  // States
  const [friendIdInput, setFriendIdInput] = useState('');
  const [joinRoomIdInput, setJoinRoomIdInput] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [isJoining, setIsJoining] = useState(false);
  const [copied, setCopied] = useState(false);

  // Settings States
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  const [activeSettingsTab, setActiveSettingsTab] = useState<'main' | 'username' | 'email' | 'password'>('main');

  // Data
  const [friends, setFriends] = useState<any[]>([]);
  const [friendRequests, setFriendRequests] = useState<any[]>([]);
  const [invites, setInvites] = useState<any[]>([]);
  const [pastChats, setPastChats] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);

  useEffect(() => {
    const fetchUser = async () => {
      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setUserData(docSnap.data());
      }
    };
    fetchUser();
  }, [user]);

  // Update Last Active
  useEffect(() => {
    if (user?.uid) {
      updateDoc(doc(db, 'users', user.uid), {
        lastActive: new Date().toISOString()
      }).catch(() => {});
    }
  }, [user]);

  // Real-time listeners
  useEffect(() => {
    if (!userData?.accountId) return;

    // Arkadaşlık İstekleri
    const reqQ = query(collection(db, 'friendRequests'), where('toAccountId', '==', userData.accountId), where('status', '==', 'pending'));
    const unsubReq = onSnapshot(reqQ, (snap) => {
      setFriendRequests(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    // Arkadaşlar
    const friendsQ = query(collection(db, `users/${user.uid}/friends`));
    const unsubFriends = onSnapshot(friendsQ, (snap) => {
      setFriends(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    // Sohbet Davetleri
    const invQ = query(collection(db, 'invites'), where('toUid', '==', user.uid));
    const unsubInv = onSnapshot(invQ, (snap) => {
      setInvites(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    // Geçmiş Sohbetler (Son 24 saat)
    const chatsQ = query(collection(db, 'rooms'), where('participants', 'array-contains', user.uid));
    const unsubChats = onSnapshot(chatsQ, (snap) => {
      const now = new Date().getTime();
      const validChats = snap.docs.map(d => ({ id: d.id, ...d.data() }))
        .filter((chat: any) => {
          const time = chat.lastMessageAt?.toMillis() || (chat.createdAt ? new Date(chat.createdAt).getTime() : 0);
          if (!time) return false;
          return (now - time) < 24 * 60 * 60 * 1000; // 24 saat
        })
        .sort((a: any, b: any) => {
          const timeA = a.lastMessageAt?.toMillis() || (a.createdAt ? new Date(a.createdAt).getTime() : 0);
          const timeB = b.lastMessageAt?.toMillis() || (b.createdAt ? new Date(b.createdAt).getTime() : 0);
          return timeB - timeA;
        });
      setPastChats(validChats);
    });

    // Admin Users Fetch
    let unsubAdmin = () => {};
    if (userData.username === 'alicelik') {
      unsubAdmin = onSnapshot(collection(db, 'users'), (snap) => {
        setAllUsers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      });
    }

    return () => { unsubReq(); unsubFriends(); unsubInv(); unsubChats(); unsubAdmin(); };
  }, [userData, user.uid]);

  const handleLogout = () => signOut(auth);

  const copyId = () => {
    if (!userData?.accountId) return;
    navigator.clipboard.writeText(userData.accountId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const showMessage = (msg: string, isError = false) => {
    if (isError) setError(msg);
    else setSuccess(msg);
    setTimeout(() => { setError(''); setSuccess(''); }, 3000);
  };

  const checkBan = () => {
    if (userData?.bannedUntil && new Date(userData.bannedUntil) > new Date()) {
      const dateStr = new Date(userData.bannedUntil).toLocaleString('tr-TR');
      showMessage(`${dateStr} tarihine kadar yasaklandınız.`, true);
      return true;
    }
    return false;
  };

  // Arkadaş Ekleme
  const handleSendFriendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (checkBan()) return;
    if (!friendIdInput.trim()) return;
    if (friendIdInput === userData.accountId) {
      showMessage('Kendine istek gönderemezsin.', true);
      return;
    }
    setLoading(true);
    try {
      const q = query(collection(db, 'users'), where('accountId', '==', friendIdInput));
      const snap = await getDocs(q);
      if (snap.empty) {
        showMessage('Bu ID ile bir kullanıcı bulunamadı.', true);
        setLoading(false);
        return;
      }
      const targetUser = snap.docs[0].data();
      
      if (targetUser.acceptFriendRequests === false) {
        showMessage('Bu kullanıcı arkadaşlık isteklerini kapattı.', true);
        setLoading(false);
        return;
      }
      
      const friendSnap = await getDoc(doc(db, `users/${user.uid}/friends`, targetUser.uid));
      if (friendSnap.exists()) {
        showMessage('Bu kişi zaten arkadaşın.', true);
        setLoading(false);
        return;
      }

      await setDoc(doc(collection(db, 'friendRequests')), {
        fromUid: user.uid,
        fromAccountId: userData.accountId,
        fromUsername: userData.username,
        toUid: targetUser.uid,
        toAccountId: targetUser.accountId,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      showMessage('Arkadaşlık isteği gönderildi!');
      setFriendIdInput('');
    } catch (err) {
      showMessage('İstek gönderilemedi.', true);
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptRequest = async (req: any) => {
    if (checkBan()) return;
    try {
      await setDoc(doc(db, `users/${user.uid}/friends`, req.fromUid), {
        uid: req.fromUid,
        accountId: req.fromAccountId,
        username: req.fromUsername,
        addedAt: new Date().toISOString()
      });
      await setDoc(doc(db, `users/${req.fromUid}/friends`, user.uid), {
        uid: user.uid,
        accountId: userData.accountId,
        username: userData.username,
        addedAt: new Date().toISOString()
      });
      await deleteDoc(doc(db, 'friendRequests', req.id));
      showMessage('İstek kabul edildi.');
    } catch (e) {
      showMessage('Hata oluştu.', true);
    }
  };

  const handleRejectRequest = async (reqId: string) => {
    await deleteDoc(doc(db, 'friendRequests', reqId));
  };

  // Sohbet Başlatma / Davet Etme
  const handleInviteToChat = async (friend: any) => {
    if (checkBan()) return;
    try {
      const roomId = Math.random().toString(36).substring(2, 15);
      await setDoc(doc(db, 'rooms', roomId), {
        name: `${userData.username} & ${friend.username}`,
        type: 'private',
        createdBy: user.uid,
        participants: [user.uid],
        participantDetails: [
          { uid: user.uid, username: userData.username, accountId: userData.accountId }
        ],
        createdAt: new Date().toISOString()
      });

      await updateDoc(doc(db, 'users', user.uid), {
        totalChatsCreated: (userData.totalChatsCreated || 0) + 1
      });

      await setDoc(doc(collection(db, 'invites')), {
        fromUid: user.uid,
        fromUsername: userData.username,
        toUid: friend.uid,
        roomId: roomId,
        createdAt: new Date().toISOString()
      });

      navigate(`/chat/${roomId}`);
    } catch (e) {
      showMessage('Sohbet başlatılamadı.', true);
    }
  };

  const handleAcceptInvite = async (invite: any) => {
    if (checkBan()) return;
    
    try {
      const roomRef = doc(db, 'rooms', invite.roomId);
      const roomSnap = await getDoc(roomRef);
      if (roomSnap.exists()) {
        const roomData = roomSnap.data();
        const newParticipants = [...(roomData.participants || []), user.uid];
        const newDetails = [...(roomData.participantDetails || []), { uid: user.uid, username: userData.username, accountId: userData.accountId }];
        
        await updateDoc(roomRef, {
          participants: newParticipants,
          participantDetails: newDetails
        });
      }
    } catch (err) {
      console.error("Odaya katılırken hata:", err);
    }

    await deleteDoc(doc(db, 'invites', invite.id));
    navigate(`/chat/${invite.roomId}`);
  };

  const handleRejectInvite = async (inviteId: string) => {
    await deleteDoc(doc(db, 'invites', inviteId));
  };

  // Yeni Paylaşılabilir Sohbet Başlat
  const handleCreateShareableRoom = async () => {
    if (checkBan()) return;
    setLoading(true);
    try {
      const key = await generateRoomKey();
      const keyBase64 = await exportKeyToBase64(key);
      const roomId = Math.random().toString(36).substring(2, 12);
      
      await setDoc(doc(db, 'rooms', roomId), {
        name: `${userData.username} Sohbeti`,
        createdAt: new Date().toISOString(),
        type: 'shareable', 
        createdBy: user.uid,
        participants: [user.uid],
        participantDetails: [{ uid: user.uid, username: userData.username, accountId: userData.accountId }]
      });

      await updateDoc(doc(db, 'users', user.uid), {
        totalChatsCreated: (userData.totalChatsCreated || 0) + 1
      });

      const fullCode = `${roomId}#${keyBase64}`;
      alert(`Sohbet oluşturuldu!\n\nKatılım Kodunuz: ${fullCode}\n\nBu kodu arkadaşlarınızla paylaşarak sohbete katılmalarını sağlayabilirsiniz.`);
      navigate(`/chat/${roomId}#${keyBase64}`);
    } catch (err) {
      showMessage('Oda oluşturulamadı.', true);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinShareableRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (checkBan()) return;
    if (!joinRoomIdInput.includes('#')) {
      showMessage('Geçersiz kod formatı. İçinde # olmalı.', true);
      return;
    }
    setIsJoining(true);
    const [roomId, keyBase64] = joinRoomIdInput.split('#');
    navigate(`/chat/${roomId}#${keyBase64}`);
    setIsJoining(false);
  };

  // Ayarlar Güncelleme
  const handleUpdateUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim()) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), { username: newUsername });
      setUserData({ ...userData, username: newUsername });
      showMessage('Kullanıcı adı güncellendi.');
      setNewUsername('');
    } catch (err) {
      showMessage('Kullanıcı adı güncellenemedi.', true);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim()) return;
    setLoading(true);
    try {
      if (auth.currentUser) {
        await updateEmail(auth.currentUser, newEmail);
        await updateDoc(doc(db, 'users', user.uid), { email: newEmail });
        setUserData({ ...userData, email: newEmail });
        showMessage('E-posta güncellendi.');
        setNewEmail('');
      }
    } catch (err: any) {
      if (err.code === 'auth/requires-recent-login') {
        showMessage('Bu işlem için yeniden giriş yapmalısınız.', true);
      } else {
        showMessage('E-posta güncellenemedi.', true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      showMessage('Yeni şifreler eşleşmiyor.', true);
      return;
    }
    setLoading(true);
    try {
      if (auth.currentUser) {
        await updatePassword(auth.currentUser, newPassword);
        showMessage('Şifre güncellendi.');
        setOldPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
      }
    } catch (err: any) {
      if (err.code === 'auth/requires-recent-login') {
        showMessage('Bu işlem için yeniden giriş yapmalısınız.', true);
      } else {
        showMessage('Şifre güncellenemedi.', true);
      }
    } finally {
      setLoading(false);
    }
  };

  // Admin Actions
  const [banInputs, setBanInputs] = useState<Record<string, { days: number, hours: number }>>({});

  const handleBanInput = (uid: string, field: 'days' | 'hours', value: string) => {
    setBanInputs(prev => ({
      ...prev,
      [uid]: {
        ...(prev[uid] || { days: 0, hours: 0 }),
        [field]: parseInt(value) || 0
      }
    }));
  };

  const handleCustomBan = async (uid: string) => {
    const days = banInputs[uid]?.days || 0;
    const hours = banInputs[uid]?.hours || 0;
    if (days === 0 && hours === 0) {
      showMessage('Lütfen gün veya saat girin.', true);
      return;
    }
    
    const banDate = new Date();
    banDate.setDate(banDate.getDate() + days);
    banDate.setHours(banDate.getHours() + hours);
    
    await updateDoc(doc(db, 'users', uid), {
      bannedUntil: banDate.toISOString()
    });
    showMessage(`${days} gün ${hours} saat yasaklandı.`);
  };

  const handleRemoveBan = async (uid: string) => {
    await updateDoc(doc(db, 'users', uid), {
      bannedUntil: null
    });
    showMessage('Yasak kaldırıldı.');
  };

  const handleDeleteUser = async (uid: string) => {
    if (window.confirm('Bu hesabı silmek istediğinize emin misiniz?')) {
      try {
        await deleteDoc(doc(db, 'users', uid));
        showMessage('Hesap silindi.');
      } catch (err) {
        console.error(err);
        await updateDoc(doc(db, 'users', uid), {
          bannedUntil: new Date('2099-01-01').toISOString(),
          deleted: true
        });
        showMessage('Hesap silinemedi ancak kalıcı olarak yasaklandı.');
      }
    }
  };

  return (
    <div className="w-full h-[100dvh] flex flex-col p-4 pt-20 md:pt-6 overflow-hidden relative">
      
      {/* Header */}
      <button 
        onClick={() => navigate('/dashboard')}
        className="fixed top-4 left-4 md:top-6 md:left-6 z-[200] px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl text-white/90 font-bold text-sm shadow-xl lowercase cursor-pointer hover:bg-white/20 transition-colors"
      >
        hizliyim.com
      </button>
      
      <div className="fixed top-4 right-4 md:top-6 md:right-6 z-[200] flex gap-3">
        {userData?.username === 'alicelik' && (
            <button 
              onClick={() => setIsAdminPanelOpen(true)} 
              className="p-3 bg-red-500/20 backdrop-blur-md border border-red-500/30 rounded-xl text-red-400 hover:bg-red-500/30 transition-all shadow-xl"
              title="Admin Paneli"
            >
              <Shield size={20} />
            </button>
          )}
          <button 
            onClick={() => setIsNotificationsOpen(true)} 
            className="p-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all shadow-xl relative"
            title="Bildirimler"
          >
            <Bell size={20} />
            {(friendRequests.length > 0 || invites.length > 0) && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-black"></span>
            )}
          </button>
          <button 
            onClick={() => setIsMenuOpen(true)} 
            className="p-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all shadow-xl relative"
            title="Hesabım"
          >
            <User size={20} />
          </button>
      </div>

      {/* Main Content: Chats */}
      <GlassPanel className="flex-1 w-full max-w-7xl mx-auto overflow-hidden flex flex-col !p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <MessageSquare size={24}/> Sohbetler
          </h2>
          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <form onSubmit={handleJoinShareableRoom} className="flex gap-2">
              <input type="text" placeholder="Oda Kodu (# ile)" className="custom-input !mb-0 w-full sm:w-48 !p-2 !text-sm" value={joinRoomIdInput} onChange={e=>setJoinRoomIdInput(e.target.value)} />
              <button type="submit" className="action-btn !mt-0 !w-auto px-4 !p-2 !text-sm" disabled={isJoining}>Katıl</button>
            </form>
            <button onClick={handleCreateShareableRoom} className="action-btn !mt-0 !w-auto px-4 bg-green-600 hover:bg-green-500 flex items-center justify-center gap-2 !p-2 !text-sm" disabled={loading}>
              <MessageSquare size={16}/> Yeni Sohbet Başlat
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto pr-2 flex flex-col gap-4 scrollbar-hide">
          {/* Past Chats */}
          <div className="flex flex-col gap-3">
            {pastChats.length === 0 ? (
              <p className="text-white/40 text-sm text-center py-4">Aktif bir sohbetin bulunmuyor.</p>
            ) : (
              pastChats.map(chat => {
                const time = chat.lastMessageAt?.toDate() || new Date(chat.createdAt);
                const timeStr = time.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                const isUnread = chat.readBy && !chat.readBy.includes(user.uid) && chat.lastMessageAt;
                
                return (
                  <div key={chat.id} onClick={() => navigate(`/chat/${chat.id}`)} className="flex items-center justify-between bg-black/20 hover:bg-white/10 cursor-pointer p-5 rounded-2xl border border-white/5 transition-colors relative">
                    <div className="flex items-center gap-4">
                      <div className="w-3 flex justify-center flex-shrink-0">
                        {isUnread && (
                          <div className="w-3 h-3 rounded-full bg-[#027aff] shadow-[0_0_12px_#027aff] animate-pulse"></div>
                        )}
                      </div>
                      <div>
                        <p className="text-white font-bold text-base">
                          {chat.name || (chat.type === 'anonymous' ? 'Anonim Oda' : 'Sohbet Odası')}
                        </p>
                        <p className="text-white/50 text-sm mt-1">
                          {chat.participantDetails?.map((p:any) => p.username).join(', ') || 'Katılımcılar...'}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2 flex-shrink-0 ml-4">
                      <span className="text-white/30 text-[11px]">{timeStr}</span>
                      <MessageSquare size={18} className="text-white/50" />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </GlassPanel>

      {/* Notifications Menu */}
      {isNotificationsOpen && (
        <div className="fixed inset-0 z-[200] flex justify-end">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsNotificationsOpen(false)}></div>
          
          <div className="relative w-full max-w-sm h-full bg-black/40 backdrop-blur-2xl border-l border-white/10 p-6 flex flex-col overflow-y-auto animate-slide-in-right shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Bell size={20}/> Bildirimler
              </h2>
              <button onClick={() => setIsNotificationsOpen(false)} className="text-white/50 hover:text-white p-2">
                <X size={24}/>
              </button>
            </div>

            {error && <div className="error-message animate-shake w-full !py-2 !mb-4">{error}</div>}
            {success && <div className="bg-green-500/20 border border-green-500/50 text-green-200 text-sm p-2 rounded-xl mb-4 w-full text-center">{success}</div>}

            <div className="flex flex-col gap-6">
              {/* Invites */}
              <div>
                <h3 className="text-white/70 text-xs uppercase tracking-wider font-bold mb-3 flex items-center gap-2"><MessageSquare size={14}/> Gelen Davetler</h3>
                {invites.length === 0 ? (
                  <p className="text-white/40 text-xs">Davet bulunmuyor.</p>
                ) : (
                  <div className="flex flex-col gap-2">
                    {invites.map(inv => (
                      <div key={inv.id} className="flex items-center justify-between bg-blue-500/10 p-3 rounded-xl border border-blue-500/30">
                        <div>
                          <p className="text-white font-bold text-sm">{inv.fromUsername}</p>
                          <p className="text-white/50 text-xs">Sohbete davet ediyor!</p>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handleAcceptInvite(inv)} className="p-2 bg-green-500/20 hover:bg-green-500/40 text-green-400 rounded-lg"><Check size={16}/></button>
                          <button onClick={() => handleRejectInvite(inv.id)} className="p-2 bg-red-500/20 hover:bg-red-500/40 text-red-400 rounded-lg"><X size={16}/></button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Friend Requests */}
              <div>
                <h3 className="text-white/70 text-xs uppercase tracking-wider font-bold mb-3 flex items-center gap-2"><UserPlus size={14}/> Arkadaşlık İstekleri</h3>
                {friendRequests.length === 0 ? (
                  <p className="text-white/40 text-xs">İstek bulunmuyor.</p>
                ) : (
                  <div className="flex flex-col gap-2">
                    {friendRequests.map(req => (
                      <div key={req.id} className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/10">
                        <div>
                          <p className="text-white font-bold text-sm">{req.fromUsername}</p>
                          <p className="text-white/50 text-xs">Arkadaş eklemek istiyor</p>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handleAcceptRequest(req)} className="p-2 bg-green-500/20 hover:bg-green-500/40 text-green-400 rounded-lg"><Check size={16}/></button>
                          <button onClick={() => handleRejectRequest(req.id)} className="p-2 bg-red-500/20 hover:bg-red-500/40 text-red-400 rounded-lg"><X size={16}/></button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Side Menu (Account) */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-[200] flex justify-end">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
          
          <div className="relative w-full max-w-sm h-full bg-black/40 backdrop-blur-2xl border-l border-white/10 p-6 flex flex-col overflow-y-auto animate-slide-in-right shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <User size={20}/> Hesabım
              </h2>
              <button onClick={() => setIsMenuOpen(false)} className="text-white/50 hover:text-white p-2">
                <X size={24}/>
              </button>
            </div>

            <div className="mb-6 text-center">
              <p className="text-white font-bold text-lg">Merhaba, {userData?.username || 'Kullanıcı'}</p>
            </div>

            {error && <div className="error-message animate-shake w-full !py-2 !mb-4">{error}</div>}
            {success && <div className="bg-green-500/20 border border-green-500/50 text-green-200 text-sm p-2 rounded-xl mb-4 w-full text-center">{success}</div>}

            <div className="flex flex-col gap-8">
              
              {/* Profile Section */}
              <div className="w-full bg-black/20 rounded-2xl p-4 border border-white/10 text-center">
                <p className="text-white/70 text-xs mb-2 uppercase tracking-wider font-bold">Hesap ID</p>
                <div className="flex items-center justify-center gap-3 bg-black/40 p-3 rounded-xl mb-4">
                  <span className="text-2xl font-mono font-bold tracking-widest text-white">
                    {showId ? (userData?.accountId || '...') : '••••••••'}
                  </span>
                  <button onClick={() => setShowId(!showId)} className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white" title={showId ? "Gizle" : "Göster"}>
                    {showId ? <Eye size={18} /> : <EyeOff size={18} />}
                  </button>
                  <button onClick={copyId} className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white" title="Kopyala">
                    {copied ? <Check className="text-green-400" size={18} /> : <Copy size={18} />}
                  </button>
                </div>
                
                <div className="flex flex-col gap-2">
                  <button onClick={() => navigate('/account-info')} className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 p-3 rounded-xl border border-blue-500/30 transition-colors flex items-center justify-center gap-2 font-bold text-sm">
                    <User size={16}/> Hesap Bilgilerim
                  </button>
                  <button onClick={() => navigate('/settings')} className="w-full bg-white/5 hover:bg-white/10 text-white p-3 rounded-xl border border-white/10 transition-colors flex items-center justify-center gap-2 font-bold text-sm">
                    <Lock size={16}/> Hesap Ayarları
                  </button>
                </div>
              </div>

              {/* Friends Section */}
              <div className="w-full">
                <h3 className="text-white/70 text-xs uppercase tracking-wider font-bold mb-3 flex items-center gap-2"><Users size={14}/> Arkadaşlar</h3>
                
                <form onSubmit={handleSendFriendRequest} className="w-full bg-black/20 p-3 rounded-xl border border-white/5 mb-4">
                  <div className="flex gap-2">
                    <input type="text" placeholder="Hesap ID gir..." className="custom-input !mb-0 flex-1 !p-2 !text-sm" value={friendIdInput} onChange={(e) => setFriendIdInput(e.target.value)} required />
                    <button type="submit" className="action-btn !mt-0 !w-auto px-3 flex items-center gap-2" disabled={loading}>
                      <UserPlus size={16} />
                    </button>
                  </div>
                </form>

                <div className="flex flex-col gap-2 max-h-40 overflow-y-auto scrollbar-hide">
                  {friends.length === 0 ? (
                    <p className="text-white/40 text-xs text-center py-2">Henüz arkadaşın yok.</p>
                  ) : (
                    friends.map(f => (
                      <div key={f.id} className="flex items-center justify-between bg-black/20 p-2 rounded-xl border border-white/5">
                        <p className="text-white font-bold text-sm">{f.username}</p>
                        <button onClick={() => { handleInviteToChat(f); setIsMenuOpen(false); }} className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg flex items-center gap-1 transition-colors">
                          <MessageSquare size={12}/> Davet
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Settings Section Removed - Moved to separate page */}
            </div>

            <button onClick={handleLogout} className="mt-auto flex items-center justify-center gap-2 w-full py-3 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-xl text-red-400 font-bold transition-all">
              <LogOut size={18} /> Çıkış Yap
            </button>
          </div>
        </div>
      )}

      {/* Admin Panel */}
      {isAdminPanelOpen && (
        <div className="fixed inset-0 z-[200] flex justify-end">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsAdminPanelOpen(false)}></div>
          
          <div className="relative w-full max-w-2xl h-full bg-black/40 backdrop-blur-2xl border-l border-white/10 p-6 flex flex-col overflow-y-auto animate-slide-in-right shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Shield size={20}/> Admin Paneli
              </h2>
              <button onClick={() => setIsAdminPanelOpen(false)} className="text-white/50 hover:text-white p-2">
                <X size={24}/>
              </button>
            </div>

            {error && <div className="error-message animate-shake w-full !py-2 !mb-4">{error}</div>}
            {success && <div className="bg-green-500/20 border border-green-500/50 text-green-200 text-sm p-2 rounded-xl mb-4 w-full text-center">{success}</div>}

            <div className="flex flex-col gap-4">
              {allUsers.map(u => (
                <div key={u.id} className="bg-white/5 p-4 rounded-xl border border-white/10 flex flex-col gap-2">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                    <div>
                      <p className="text-white font-bold text-lg">{u.username} <span className="text-white/40 text-xs font-normal">({u.email})</span></p>
                      <p className="text-white/50 text-xs mt-1">Son Aktif: {u.lastActive ? new Date(u.lastActive).toLocaleString('tr-TR') : 'Bilinmiyor'}</p>
                      <p className="text-white/50 text-xs">Açılan Sohbet: {u.totalChatsCreated || 0}</p>
                      {u.bannedUntil && new Date(u.bannedUntil) > new Date() && (
                        <p className="text-red-400 text-xs mt-1 font-bold flex items-center gap-1">
                          <Ban size={12}/> Yasaklı: {new Date(u.bannedUntil).toLocaleString('tr-TR')}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2 flex-wrap justify-end items-center mt-2">
                      <div className="flex items-center gap-1 bg-black/20 p-1 rounded-lg border border-white/10">
                        <input type="number" placeholder="Gün" className="w-12 bg-transparent text-white text-xs text-center outline-none" onChange={(e) => handleBanInput(u.id, 'days', e.target.value)} />
                        <span className="text-white/50 text-xs">g</span>
                        <input type="number" placeholder="Saat" className="w-12 bg-transparent text-white text-xs text-center outline-none border-l border-white/10 pl-1" onChange={(e) => handleBanInput(u.id, 'hours', e.target.value)} />
                        <span className="text-white/50 text-xs">s</span>
                        <button onClick={() => handleCustomBan(u.id)} className="px-2 py-1 bg-orange-500/20 text-orange-400 text-xs rounded hover:bg-orange-500/40 border border-orange-500/30 ml-1">Banla</button>
                      </div>
                      <button onClick={() => handleRemoveBan(u.id)} className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded hover:bg-green-500/40 border border-green-500/30">Ban Kaldır</button>
                      <button onClick={() => handleDeleteUser(u.id)} className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded hover:bg-red-500/40 border border-red-500/30 flex items-center gap-1"><Trash2 size={12}/> Sil</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl text-blue-200 text-sm">
              <p><strong>Not:</strong> Yeni hesap eklemek için sistemden çıkış yapıp normal kayıt ekranını kullanabilirsiniz.</p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
