import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassPanel } from '../components/GlassPanel';
import { auth, db, loginAnonymously } from '../firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { generateRoomKey, exportKeyToBase64 } from '../utils/crypto';
import { Loader2 } from 'lucide-react';

type ViewState = 'login' | 'register' | 'anonymous';

export function AuthPage() {
  const [view, setView] = useState<ViewState>('login');
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Anonim oda için
  const [joinKey, setJoinKey] = useState('');

  // Görünüm değiştiğinde hataları ve formları temizle
  useEffect(() => {
    setError('');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setUsername('');
    setJoinKey('');
  }, [view]);

  const translateError = (code: string, defaultMsg: string) => {
    switch (code) {
      case 'auth/email-already-in-use': return 'Bu e-posta adresi zaten kullanımda.';
      case 'auth/invalid-email': return 'Geçersiz e-posta adresi.';
      case 'auth/weak-password': return 'Şifre çok zayıf (en az 6 karakter olmalı).';
      case 'auth/user-not-found':
      case 'auth/wrong-password':
      case 'auth/invalid-credential': return 'Kullanıcı adı, e-posta veya şifre hatalı.';
      case 'auth/operation-not-allowed': return 'Anonim veya E-posta girişi Firebase üzerinden kapalı.';
      default: return defaultMsg + ' (' + code + ')';
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      let loginEmail = email;
      
      // Eğer girilen değerde @ yoksa, kullanıcı adı olarak kabul et ve e-postasını bul
      if (!email.includes('@')) {
        const q = query(collection(db, 'users'), where('username', '==', email));
        const snap = await getDocs(q);
        if (snap.empty) {
          // Admin otomatik oluşturma kontrolü
          if (email === 'alicelik' && password === 'alicelik6506') {
            try {
              const cred = await createUserWithEmailAndPassword(auth, 'alicelik@hizliyim.com', password);
              await setDoc(doc(db, 'users', cred.user.uid), {
                uid: cred.user.uid,
                accountId: '00000000',
                username: 'alicelik',
                email: 'alicelik@hizliyim.com',
                createdAt: new Date().toISOString(),
                role: 'admin'
              });
              return; // Başarılı giriş
            } catch (adminErr: any) {
              if (adminErr.code === 'auth/email-already-in-use') {
                 await signInWithEmailAndPassword(auth, 'alicelik@hizliyim.com', password);
                 return;
              }
              throw adminErr;
            }
          }
          throw { code: 'auth/user-not-found' };
        }
        loginEmail = snap.docs[0].data().email;
      }

      await signInWithEmailAndPassword(auth, loginEmail, password);
    } catch (err: any) {
      setError(translateError(err.code || err.message, 'Giriş yapılamadı.'));
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('Şifreler birbiriyle uyuşmuyor!');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      // 8 haneli rastgele sayısal ID oluştur
      const accountId = Math.floor(10000000 + Math.random() * 90000000).toString();
      
      await setDoc(doc(db, 'users', user.uid), {
        uid: user.uid,
        accountId: accountId,
        username,
        email: email.toLowerCase(),
        createdAt: new Date().toISOString(),
      });
      
    } catch (err: any) {
      setError(translateError(err.code, 'Kayıt olurken bir hata oluştu.'));
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAnonymousRoom = async () => {
    setLoading(true);
    setError('');
    try {
      await loginAnonymously();
      const key = await generateRoomKey();
      const keyBase64 = await exportKeyToBase64(key);
      const roomId = Math.random().toString(36).substring(2, 12);
      
      await setDoc(doc(db, 'rooms', roomId), {
        createdAt: new Date().toISOString(),
        type: 'anonymous',
        createdBy: auth.currentUser?.uid
      });

      const fullCode = `${roomId}#${keyBase64}`;
      alert(`Oda oluşturuldu!\n\nOda Kodunuz: ${fullCode}\n\nBu kodu arkadaşınızla paylaşın.`);
      navigate(`/chat/${roomId}#${keyBase64}`);
    } catch (err: any) {
      console.error("Oda oluşturma hatası:", err);
      setError('Oda oluşturulamadı. Lütfen tekrar deneyin.');
    } finally {
      setLoading(false);
    }
  };

  const handleJoinAnonymousRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinKey.includes('#')) {
      setError('Geçersiz oda anahtarı formatı. İçinde # olmalı.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await loginAnonymously();
      const [roomId, keyBase64] = joinKey.split('#');
      
      const roomSnap = await getDoc(doc(db, 'rooms', roomId));
      if (!roomSnap.exists()) {
        setError('Oda bulunamadı veya süresi dolmuş.');
        setLoading(false);
        return;
      }

      navigate(`/chat/${roomId}#${keyBase64}`);
    } catch (err: any) {
      setError(translateError(err.code, 'Odaya katılınamadı.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full h-screen flex flex-col justify-center items-center p-4 overflow-y-auto">
      <div className="absolute top-4 left-4 z-[100] px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl text-white/90 font-bold text-sm shadow-xl">
        hizliyim.com
      </div>

      <GlassPanel>
        <h1 className="animated-title logo-text-night">
          hizliyim.com
        </h1>

        {error && (
          <div className="error-message animate-shake">
            {error}
          </div>
        )}

        {view === 'login' && (
          <form onSubmit={handleLogin} className="w-full animate-pop-in">
            <input
              type="text"
              placeholder="E-posta veya Kullanıcı Adı"
              className="custom-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              required
            />
            <input
              type="password"
              placeholder="Şifre"
              className="custom-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              required
            />
            <button type="submit" className="action-btn flex justify-center items-center" disabled={loading}>
              {loading ? <Loader2 className="animate-spin" /> : 'Giriş Yap'}
            </button>
            
            <div className="link-text text-center mt-4">
              Hesabın yok mu? <button type="button" onClick={() => setView('register')} className="underline font-bold text-white">Hemen Kayıt Ol</button>
            </div>
            <div className="link-text text-center mt-2">
              Veya <button type="button" onClick={() => setView('anonymous')} className="underline font-bold text-white">Anonim Sohbet Et</button>
            </div>
          </form>
        )}

        {view === 'register' && (
          <form onSubmit={handleRegister} className="w-full animate-pop-in">
            <input
              type="text"
              placeholder="Kullanıcı Adı"
              className="custom-input"
              value={username}
              onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s/g, ''))}
              autoCapitalize="none"
              autoCorrect="off"
              required
            />
            <input
              type="email"
              placeholder="E-posta Adresi"
              className="custom-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              required
            />
            <input
              type="password"
              placeholder="Şifre Belirle"
              className="custom-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              required
            />
            <input
              type="password"
              placeholder="Şifreyi Tekrar Gir"
              className="custom-input"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              required
            />
            <button type="submit" className="action-btn flex justify-center items-center" disabled={loading}>
              {loading ? <Loader2 className="animate-spin" /> : 'Kayıt Ol'}
            </button>
            
            <div className="link-text text-center mt-4">
              Hesabın var mı? <button type="button" onClick={() => setView('login')} className="underline font-bold text-white">Giriş Yap</button>
            </div>
          </form>
        )}

        {view === 'anonymous' && (
          <div className="w-full animate-pop-in">
            <button 
              onClick={handleCreateAnonymousRoom} 
              className="action-btn flex justify-center items-center mb-6" 
              disabled={loading}
            >
              {loading ? <Loader2 className="animate-spin" /> : 'Yeni Anonim Oda Oluştur'}
            </button>

            <div className="relative flex py-2 items-center mb-6">
              <div className="flex-grow border-t border-white/20"></div>
              <span className="flex-shrink-0 mx-4 text-white/50 text-sm">VEYA</span>
              <div className="flex-grow border-t border-white/20"></div>
            </div>

            <form onSubmit={handleJoinAnonymousRoom}>
              <input
                type="text"
                placeholder="Oda Anahtarı (Key)"
                className="custom-input"
                value={joinKey}
                onChange={(e) => setJoinKey(e.target.value)}
                autoCapitalize="none"
                autoCorrect="off"
                required
              />
              <button type="submit" className="action-btn flex justify-center items-center" disabled={loading}>
                {loading ? <Loader2 className="animate-spin" /> : 'Odaya Katıl'}
              </button>
            </form>

            <div className="link-text text-center mt-6">
              <button type="button" onClick={() => setView('login')} className="underline font-bold text-white">Giriş Ekranına Dön</button>
            </div>
          </div>
        )}
      </GlassPanel>
    </div>
  );
}
