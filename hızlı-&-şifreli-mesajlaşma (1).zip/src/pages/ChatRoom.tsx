import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { db } from '../firebase';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, getDoc, deleteDoc, updateDoc, arrayUnion } from 'firebase/firestore';
import { GlassPanel } from '../components/GlassPanel';
import { useTheme } from '../hooks/useTheme';
import { ArrowLeft, Send, Lock, Users, Copy, Edit2, Trash2 } from 'lucide-react';
import { importKeyFromBase64, encryptMessage, decryptMessage, deriveKeyFromPassword } from '../utils/crypto';
import { ScrambleText } from '../components/ScrambleText';

interface Message {
  id: string;
  text: string;
  senderId: string;
  senderName?: string;
  createdAt: any;
  decryptedText?: string;
}

export function ChatRoom({ user }: { user: any }) {
  const { roomId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { isDayTime } = useTheme();
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [cryptoKey, setCryptoKey] = useState<CryptoKey | null>(null);
  const [error, setError] = useState('');
  const [isEditingName, setIsEditingName] = useState(false);
  const [editNameValue, setEditNameValue] = useState('');
  const [roomData, setRoomData] = useState<any>(null);
  const [userData, setUserData] = useState<any>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchUser = async () => {
      if (!user) return;
      const docSnap = await getDoc(doc(db, 'users', user.uid));
      if (docSnap.exists()) {
        setUserData(docSnap.data());
      }
    };
    fetchUser();
  }, [user]);

  useEffect(() => {
    const initializeRoom = async () => {
      if (!roomId) return;

      try {
        const roomRef = doc(db, 'rooms', roomId);
        const roomSnap = await getDoc(roomRef);
        
        if (!roomSnap.exists()) {
          setError('Oda bulunamadı veya süresi dolmuş.');
          return;
        }

        const data = roomSnap.data();
        setRoomData(data);

        if (data.type === 'anonymous' || data.type === 'shareable') {
          let hashKey = location.hash.replace('#', '');
          
          if (!hashKey) {
            hashKey = localStorage.getItem(`roomKey_${roomId}`) || '';
          } else {
            localStorage.setItem(`roomKey_${roomId}`, hashKey);
          }

          if (!hashKey) {
            setError('Oda anahtarı eksik. Lütfen geçerli bir davet bağlantısı kullanın.');
            return;
          }
          const key = await importKeyFromBase64(hashKey);
          setCryptoKey(key);
        } else if (data.type === 'private') {
          // Özel odalar için Room ID üzerinden anahtar türetme
          const key = await deriveKeyFromPassword(roomId, 'hizliyim-salt-2026');
          setCryptoKey(key);
        }
      } catch (err) {
        console.error(err);
        setError('Şifreleme anahtarı oluşturulamadı.');
      }
    };

    initializeRoom();
  }, [roomId, location.hash]);

  useEffect(() => {
    if (roomData && user && userData && roomId) {
      const isParticipant = roomData.participants?.includes(user.uid);
      if (!isParticipant) {
        const newParticipants = [...(roomData.participants || []), user.uid];
        const newDetails = [...(roomData.participantDetails || []), { uid: user.uid, username: userData.username, accountId: userData.accountId }];
        updateDoc(doc(db, 'rooms', roomId), {
          participants: newParticipants,
          participantDetails: newDetails
        }).catch(console.error);
      }
    }
  }, [roomData, user, userData, roomId]);

  useEffect(() => {
    if (!roomId || !cryptoKey) return;

    const q = query(
      collection(db, `rooms/${roomId}/messages`),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const newMessages: Message[] = [];
      for (const doc of snapshot.docs) {
        const data = doc.data();
        let decryptedText = '⚠️ Şifre çözülemedi';
        
        try {
          decryptedText = await decryptMessage(data.text, cryptoKey);
        } catch (e) {
          console.error('Mesaj çözme hatası', e);
        }

        newMessages.push({
          id: doc.id,
          text: data.text,
          senderId: data.senderId,
          senderName: data.senderName,
          createdAt: data.createdAt,
          decryptedText
        });
      }
      setMessages(newMessages);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return () => unsubscribe();
  }, [roomId, cryptoKey]);

  useEffect(() => {
    if (roomId && user) {
      updateDoc(doc(db, 'rooms', roomId), {
        readBy: arrayUnion(user.uid)
      }).catch(console.error);
    }
  }, [roomId, user, messages.length]);

  const handleSendMessage = async (e?: React.FormEvent | React.KeyboardEvent) => {
    if (e) e.preventDefault();
    if (!newMessage.trim() || !roomId || !cryptoKey || !user) return;

    if (userData?.bannedUntil && new Date(userData.bannedUntil) > new Date()) {
      const dateStr = new Date(userData.bannedUntil).toLocaleString('tr-TR');
      setError(`${dateStr} tarihine kadar yasaklandığınız için mesaj gönderemezsiniz.`);
      return;
    }

    const textToSend = newMessage;
    setNewMessage('');

    try {
      const encryptedText = await encryptMessage(textToSend, cryptoKey);
      
      await addDoc(collection(db, `rooms/${roomId}/messages`), {
        text: encryptedText,
        senderId: user.uid,
        senderName: userData?.username || 'Anonim',
        createdAt: serverTimestamp()
      });

      await updateDoc(doc(db, 'rooms', roomId), {
        lastMessageAt: serverTimestamp(),
        readBy: [user.uid]
      });
    } catch (err) {
      console.error('Mesaj gönderme hatası:', err);
      setError('Mesaj gönderilemedi.');
    }
  };

  const handleSaveRoomName = async () => {
    if (!editNameValue.trim() || !roomId) {
      setIsEditingName(false);
      return;
    }
    try {
      await updateDoc(doc(db, 'rooms', roomId), {
        name: editNameValue.trim()
      });
      setRoomData((prev: any) => ({ ...prev, name: editNameValue.trim() }));
    } catch (err) {
      console.error(err);
    }
    setIsEditingName(false);
  };

  const handleDeleteForMe = async () => {
    if (window.confirm("Bu sohbet sadece sizden silinecek. Karşı tarafta kalmaya devam edecek. Onaylıyor musunuz?")) {
      try {
        const newParticipants = roomData.participants.filter((p: string) => p !== user.uid);
        await updateDoc(doc(db, 'rooms', roomId!), {
          participants: newParticipants
        });
        navigate('/dashboard', { replace: true });
      } catch (err) {
        console.error(err);
        setError('Sohbet silinemedi.');
      }
    }
  };

  const handleGoBack = async () => {
    try {
      if (roomData?.type === 'anonymous') {
        if (roomData?.createdBy === user?.uid) {
          const confirmDelete = window.confirm("Eğer çıkarsanız sohbet silinecek. Çıkmak istediğinize emin misiniz?");
          if (confirmDelete) {
            await deleteDoc(doc(db, 'rooms', roomId!));
            navigate('/dashboard', { replace: true });
          }
        } else {
          const confirmLeave = window.confirm("Odadan çıkmak istediğinize emin misiniz?");
          if (confirmLeave) {
            navigate('/dashboard', { replace: true });
          }
        }
      } else {
        navigate('/dashboard', { replace: true });
      }
    } catch (err) {
      console.error("Çıkış hatası:", err);
      navigate('/dashboard', { replace: true });
    }
  };

  if (error) {
    return (
      <div className="w-full h-screen flex justify-center items-center p-4">
        <GlassPanel>
          <div className="error-message">{error}</div>
          <button onClick={() => navigate(-1)} className="action-btn mt-4">Geri Dön</button>
        </GlassPanel>
      </div>
    );
  }

  if (!cryptoKey) {
    return (
      <div className="w-full h-screen flex justify-center items-center p-4">
        <GlassPanel>
          <div className="spinner"></div>
          <p className="text-white text-center mt-4">Güvenli bağlantı kuruluyor...</p>
        </GlassPanel>
      </div>
    );
  }

  return (
    <div className="w-full h-[100dvh] flex flex-col items-center p-0 md:p-4 relative">
      {/* Logo - Always visible */}
      <button 
        onClick={() => navigate('/dashboard')}
        className="fixed top-4 left-4 md:top-6 md:left-6 z-[200] px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl text-white/90 font-bold text-sm shadow-xl lowercase cursor-pointer hover:bg-white/20 transition-colors"
      >
        hizliyim.com
      </button>

      <GlassPanel className="max-w-[900px] w-full h-full flex flex-col items-stretch p-4 pt-20 md:p-6 md:pt-20 rounded-none md:rounded-3xl relative">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-white/10 pb-4 mb-4 relative z-10">
          <button 
            onClick={handleGoBack}
            className="p-2 md:p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-colors text-white flex-shrink-0 z-50 cursor-pointer"
          >
            <ArrowLeft size={24} />
          </button>
          
          <div className="flex flex-col items-center flex-1 px-2 md:px-4">
            {isEditingName ? (
              <input 
                type="text" 
                value={editNameValue} 
                onChange={e => setEditNameValue(e.target.value)}
                onBlur={handleSaveRoomName}
                onKeyDown={e => e.key === 'Enter' && handleSaveRoomName()}
                autoFocus
                className="bg-black/40 border border-white/20 rounded-lg px-3 py-1 text-white text-sm outline-none text-center font-bold mb-1"
                placeholder="Oda İsmi"
              />
            ) : (
              <h2 
                className="text-white font-bold flex items-center gap-2 text-center cursor-pointer hover:text-white/80 transition-colors" 
                onClick={() => { setEditNameValue(roomData?.name || ''); setIsEditingName(true); }}
                title="İsmi Düzenle"
              >
                <Lock size={16} className="text-green-400" /> 
                {roomData?.name || (roomData?.type === 'anonymous' ? 'Anonim Oda' : (roomData?.type === 'shareable' ? 'Kullanıcılar' : 'Özel Sohbet'))}
                <Edit2 size={12} className="text-white/40 ml-1" />
              </h2>
            )}
            <span className="text-white/50 text-xs mt-1 flex items-center gap-1 text-center">
              <Users size={12} />
              {roomData?.participantDetails?.map((p:any) => p.username).join(', ') || 'Katılımcılar...'}
            </span>
            {(roomData?.type === 'anonymous' || roomData?.type === 'shareable') && (
              <div className="flex items-center gap-2 mt-2">
                <span className="text-white/60 text-[11px] font-mono bg-black/40 px-2 py-1 rounded-lg border border-white/10">
                  Kod: {roomId}{localStorage.getItem(`roomKey_${roomId}`)?.substring(0, 4)}...{localStorage.getItem(`roomKey_${roomId}`)?.substring(localStorage.getItem(`roomKey_${roomId}`)!.length - 4)}
                </span>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(`${roomId}#${localStorage.getItem(`roomKey_${roomId}`)}`);
                    alert('Oda kodu kopyalandı!');
                  }}
                  className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
                  title="Kodu Kopyala"
                >
                  <Copy size={14} />
                </button>
              </div>
            )}
          </div>
          
          <button 
            onClick={handleDeleteForMe}
            className="p-2 md:p-3 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-xl transition-colors text-red-400 flex-shrink-0 z-50 cursor-pointer"
            title="Sohbeti Benden Sil"
          >
            <Trash2 size={20} />
          </button>
        </div>

        {/* Messages Area */}
        <div className="flex-1 w-full overflow-y-auto pr-2 flex flex-col gap-4 mb-4 scrollbar-hide">
          {messages.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-white/40 text-sm text-center">
              Mesajlar uçtan uca şifrelenir. <br/> Kimse, hizliyim.com bile bu mesajları okuyamaz.
            </div>
          ) : (
            messages.map((msg, index) => {
              const isMe = msg.senderId === user.uid;
              const showName = !isMe && (index === 0 || messages[index - 1].senderId !== msg.senderId);
              
              return (
                <div key={msg.id} className={`flex flex-col w-full ${isMe ? 'items-end' : 'items-start'}`}>
                  {showName && roomData?.type !== 'anonymous' && (
                    <span className="text-white/40 text-[10px] ml-1 mb-1">{msg.senderName}</span>
                  )}
                  <div 
                    className={`max-w-[85%] md:max-w-[70%] rounded-2xl p-3 px-4 text-sm flex flex-col ${
                      isMe 
                        ? 'bg-blue-600 text-white rounded-br-sm' 
                        : 'bg-white/10 text-white rounded-bl-sm border border-white/5'
                    }`}
                  >
                    <ScrambleText 
                      text={msg.decryptedText || ''} 
                      className="break-words"
                      delay={isMe ? 0 : 300}
                    />
                  </div>
                  <span className="text-white/30 text-[10px] mt-1 px-1">
                    {msg.createdAt?.toDate ? msg.createdAt.toDate().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : '...'}
                  </span>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <form onSubmit={handleSendMessage} className="flex gap-2 mt-auto items-end">
          <textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => {
              if (userData?.sendWithEnter) {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }
            }}
            placeholder="Şifreli bir mesaj yaz..."
            className="custom-input !mb-0 flex-1 bg-black/40 resize-none min-h-[44px] max-h-[120px] py-3 scrollbar-hide"
            rows={1}
            required
          />
          <button 
            type="submit"
            className="action-btn !mt-0 !w-auto px-6 h-[44px] flex items-center justify-center bg-blue-600 hover:bg-blue-500 text-white"
            disabled={!newMessage.trim()}
          >
            <Send size={20} />
          </button>
        </form>

      </GlassPanel>
    </div>
  );
}
