import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';
import { GlassPanel } from '../components/GlassPanel';
import { ArrowLeft, User, Mail, Calendar, MessageSquare } from 'lucide-react';

export function AccountInfoPage({ user }: { user: any }) {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<any>(null);

  useEffect(() => {
    const fetchUser = async () => {
      if (!user) return;
      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setUserData(docSnap.data());
      }
    };
    fetchUser();
  }, [user]);

  if (!userData) {
    return (
      <div className="w-full h-screen flex justify-center items-center p-4">
        <GlassPanel>
          <div className="spinner"></div>
        </GlassPanel>
      </div>
    );
  }

  return (
    <div className="w-full h-[100dvh] flex flex-col items-center p-4 pt-20 relative">
      <button 
        onClick={() => navigate('/dashboard')}
        className="absolute top-4 left-4 z-[100] px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl text-white/90 font-bold text-sm shadow-xl lowercase cursor-pointer hover:bg-white/20 transition-colors"
      >
        hizliyim.com
      </button>

      <GlassPanel className="max-w-[500px] w-full flex flex-col p-6 md:p-8 rounded-3xl relative">
        <div className="flex items-center gap-4 mb-8 border-b border-white/10 pb-4">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors text-white"
          >
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-xl font-bold text-white">Hesap Bilgilerim</h2>
        </div>

        <div className="flex flex-col gap-4">
          <div className="bg-black/20 p-4 rounded-xl border border-white/5 flex items-center gap-4">
            <div className="p-3 bg-blue-500/20 text-blue-400 rounded-lg">
              <User size={24} />
            </div>
            <div>
              <p className="text-white/50 text-xs mb-1">Kullanıcı Adı</p>
              <p className="text-white font-bold">{userData.username}</p>
            </div>
          </div>

          <div className="bg-black/20 p-4 rounded-xl border border-white/5 flex items-center gap-4">
            <div className="p-3 bg-green-500/20 text-green-400 rounded-lg">
              <Mail size={24} />
            </div>
            <div>
              <p className="text-white/50 text-xs mb-1">Kayıtlı E-posta</p>
              <p className="text-white font-bold">{userData.email}</p>
            </div>
          </div>

          <div className="bg-black/20 p-4 rounded-xl border border-white/5 flex items-center gap-4">
            <div className="p-3 bg-purple-500/20 text-purple-400 rounded-lg">
              <Calendar size={24} />
            </div>
            <div>
              <p className="text-white/50 text-xs mb-1">Kayıt Tarihi</p>
              <p className="text-white font-bold">
                {userData.createdAt ? new Date(userData.createdAt).toLocaleDateString('tr-TR', {
                  year: 'numeric', month: 'long', day: 'numeric'
                }) : 'Bilinmiyor'}
              </p>
            </div>
          </div>

          <div className="bg-black/20 p-4 rounded-xl border border-white/5 flex items-center gap-4">
            <div className="p-3 bg-orange-500/20 text-orange-400 rounded-lg">
              <MessageSquare size={24} />
            </div>
            <div>
              <p className="text-white/50 text-xs mb-1">Toplam Açılan Oda Sayısı</p>
              <p className="text-white font-bold text-xl">{userData.totalChatsCreated || 0}</p>
            </div>
          </div>
        </div>
      </GlassPanel>
    </div>
  );
}
