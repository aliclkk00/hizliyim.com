import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { updateEmail, updatePassword, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { GlassPanel } from '../components/GlassPanel';
import { ArrowLeft, User, Mail, Lock } from 'lucide-react';

export function SettingsPage({ user }: { user: any }) {
  const navigate = useNavigate();
  const [userData, setUserData] = useState<any>(null);
  
  const [activeTab, setActiveTab] = useState<'main' | 'username' | 'email' | 'password'>('main');
  
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      if (!user) return;
      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setUserData(docSnap.data());
      }
    };
    fetchUser();
  }, [user]);

  const showMessage = (msg: string, isError = false) => {
    if (isError) setError(msg);
    else setSuccess(msg);
    setTimeout(() => { setError(''); setSuccess(''); }, 4000);
  };

  const toggleSetting = async (field: string) => {
    if (!userData) return;
    const currentValue = userData[field];
    const newValue = field === 'acceptFriendRequests' ? (currentValue === false ? true : false) : !currentValue;
    
    setUserData({ ...userData, [field]: newValue });
    try {
      await updateDoc(doc(db, 'users', user.uid), { [field]: newValue });
    } catch (err) {
      console.error(err);
      showMessage('Ayar güncellenemedi.', true);
      setUserData({ ...userData, [field]: currentValue });
    }
  };

  const handleUpdateUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim()) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), { username: newUsername });
      setUserData({ ...userData, username: newUsername });
      showMessage('Kullanıcı adı başarıyla güncellendi.');
      setNewUsername('');
      setActiveTab('main');
    } catch (err) {
      showMessage('Kullanıcı adı güncellenemedi.', true);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim() || !oldPassword.trim()) {
      showMessage('Mevcut şifrenizi ve yeni e-postanızı girmelisiniz.', true);
      return;
    }
    setLoading(true);
    try {
      if (auth.currentUser && auth.currentUser.email) {
        const credential = EmailAuthProvider.credential(auth.currentUser.email, oldPassword);
        await reauthenticateWithCredential(auth.currentUser, credential);
        await updateEmail(auth.currentUser, newEmail);
        await updateDoc(doc(db, 'users', user.uid), { email: newEmail });
        setUserData({ ...userData, email: newEmail });
        showMessage('E-posta başarıyla güncellendi.');
        setNewEmail('');
        setOldPassword('');
        setActiveTab('main');
      }
    } catch (err: any) {
      console.error("Email update error:", err);
      if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        showMessage('Mevcut şifreniz yanlış.', true);
      } else if (err.code === 'auth/email-already-in-use') {
        showMessage('Bu e-posta adresi zaten kullanımda.', true);
      } else {
        showMessage('E-posta güncellenemedi.', true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      showMessage('Yeni şifreler eşleşmiyor.', true);
      return;
    }
    setLoading(true);
    try {
      if (auth.currentUser && auth.currentUser.email) {
        const credential = EmailAuthProvider.credential(auth.currentUser.email, oldPassword);
        await reauthenticateWithCredential(auth.currentUser, credential);
        await updatePassword(auth.currentUser, newPassword);
        showMessage('Şifre başarıyla güncellendi.');
        setOldPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
        setActiveTab('main');
      }
    } catch (err: any) {
      console.error("Password update error:", err);
      if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        showMessage('Eski şifreniz yanlış.', true);
      } else {
        showMessage('Şifre güncellenemedi.', true);
      }
    } finally {
      setLoading(false);
    }
  };

  if (!userData) {
    return (
      <div className="w-full h-screen flex justify-center items-center p-4">
        <GlassPanel>
          <div className="spinner"></div>
        </GlassPanel>
      </div>
    );
  }

  return (
    <div className="w-full h-[100dvh] flex flex-col items-center p-4 pt-20 relative">
      <button 
        onClick={() => navigate('/dashboard')}
        className="absolute top-4 left-4 z-[100] px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl text-white/90 font-bold text-sm shadow-xl lowercase cursor-pointer hover:bg-white/20 transition-colors"
      >
        hizliyim.com
      </button>

      <GlassPanel className="max-w-[500px] w-full flex flex-col p-6 md:p-8 rounded-3xl relative">
        <div className="flex items-center gap-4 mb-8 border-b border-white/10 pb-4">
          <button 
            onClick={() => activeTab === 'main' ? navigate('/dashboard') : setActiveTab('main')}
            className="p-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors text-white"
          >
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-xl font-bold text-white">
            {activeTab === 'main' && 'Hesap Ayarları'}
            {activeTab === 'username' && 'Kullanıcı Adı Değiştir'}
            {activeTab === 'email' && 'E-posta Değiştir'}
            {activeTab === 'password' && 'Şifre Değiştir'}
          </h2>
        </div>

        {error && <div className="error-message animate-shake w-full !py-2 !mb-4">{error}</div>}
        {success && <div className="bg-green-500/20 border border-green-500/50 text-green-200 text-sm p-3 rounded-xl mb-4 w-full text-center">{success}</div>}

        {activeTab === 'main' && (
          <div className="flex flex-col gap-3">
            <button onClick={() => setActiveTab('username')} className="w-full bg-black/20 p-4 rounded-xl border border-white/5 text-left hover:bg-white/10 transition-colors flex items-center gap-3">
              <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg"><User size={20}/></div>
              <span className="text-white font-bold text-sm">Kullanıcı Adı Değiştir</span>
            </button>
            <button onClick={() => setActiveTab('email')} className="w-full bg-black/20 p-4 rounded-xl border border-white/5 text-left hover:bg-white/10 transition-colors flex items-center gap-3">
              <div className="p-2 bg-green-500/20 text-green-400 rounded-lg"><Mail size={20}/></div>
              <span className="text-white font-bold text-sm">E-posta Değiştir</span>
            </button>
            <button onClick={() => setActiveTab('password')} className="w-full bg-black/20 p-4 rounded-xl border border-white/5 text-left hover:bg-white/10 transition-colors flex items-center gap-3">
              <div className="p-2 bg-orange-500/20 text-orange-400 rounded-lg"><Lock size={20}/></div>
              <span className="text-white font-bold text-sm">Şifre Değiştir</span>
            </button>

            <div className="mt-4 flex flex-col gap-3 border-t border-white/10 pt-4">
              <h3 className="text-white/70 text-xs uppercase tracking-wider font-bold mb-1">Tercihler</h3>
              
              <div className="flex items-center justify-between bg-black/20 p-4 rounded-xl border border-white/5">
                <div>
                  <p className="text-white font-bold text-sm">Enter Tuşu ile Gönder</p>
                  <p className="text-white/50 text-xs mt-1">Mesajları Enter tuşu ile gönderir</p>
                </div>
                <button 
                  onClick={() => toggleSetting('sendWithEnter')}
                  className={`w-12 h-6 rounded-full transition-colors relative ${userData?.sendWithEnter ? 'bg-green-500' : 'bg-white/20'}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${userData?.sendWithEnter ? 'left-7' : 'left-1'}`}></div>
                </button>
              </div>

              <div className="flex items-center justify-between bg-black/20 p-4 rounded-xl border border-white/5">
                <div>
                  <p className="text-white font-bold text-sm">Arkadaşlık İstekleri</p>
                  <p className="text-white/50 text-xs mt-1">Diğer kullanıcılar size istek gönderebilir</p>
                </div>
                <button 
                  onClick={() => toggleSetting('acceptFriendRequests')}
                  className={`w-12 h-6 rounded-full transition-colors relative ${userData?.acceptFriendRequests !== false ? 'bg-green-500' : 'bg-white/20'}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${userData?.acceptFriendRequests !== false ? 'left-7' : 'left-1'}`}></div>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'username' && (
          <form onSubmit={handleUpdateUsername} className="flex flex-col gap-4">
            <input type="text" placeholder="Yeni Kullanıcı Adı" className="custom-input !mb-0 w-full" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} required />
            <button type="submit" className="action-btn !mt-0 w-full" disabled={loading}>Güncelle</button>
          </form>
        )}

        {activeTab === 'email' && (
          <form onSubmit={handleUpdateEmail} className="flex flex-col gap-4">
            <input type="password" placeholder="Mevcut Şifreniz" className="custom-input !mb-0 w-full" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} required />
            <input type="email" placeholder="Yeni E-posta Adresi" className="custom-input !mb-0 w-full" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} required />
            <button type="submit" className="action-btn !mt-0 w-full" disabled={loading}>E-postayı Güncelle</button>
          </form>
        )}

        {activeTab === 'password' && (
          <form onSubmit={handleUpdatePassword} className="flex flex-col gap-4">
            <input type="password" placeholder="Mevcut Şifreniz" className="custom-input !mb-0 w-full" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} required />
            <input type="password" placeholder="Yeni Şifre" className="custom-input !mb-0 w-full" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
            <input type="password" placeholder="Yeni Şifre (Tekrar)" className="custom-input !mb-0 w-full" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} required />
            <button type="submit" className="action-btn !mt-0 w-full" disabled={loading}>Şifreyi Güncelle</button>
          </form>
        )}
      </GlassPanel>
    </div>
  );
}
